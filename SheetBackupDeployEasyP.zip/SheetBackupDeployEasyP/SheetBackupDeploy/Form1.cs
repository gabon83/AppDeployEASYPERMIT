﻿using Microsoft.SharePoint.Client;
using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Form = System.Windows.Forms.Form;
using System.Net;
using System.Media;
using System.Xml;

namespace SheetBackupDeploy
{
	public partial class Form1 : Form
	{
		private SoundPlayer soundPlayer;
		public Form1()
		{
			InitializeComponent();
			soundPlayer = new SoundPlayer("sound.wav");
		}

		private void Button1_Click(object sender, EventArgs e)
		{
			CopyFolderAndFiles("full", textBox1.Text);
		}

		private void CopyFolderAndFiles(string type, string urlSite)
		{
			try
			{
				
				
				string localPath = textBox3.Text;      //SourcePath.
				string sharePointSite = textBox1.Text;         //URL Sito.
				string documentLibraryName ="";  // SharePoint library name.
				if (checkBox1.Checked)
				{
					documentLibraryName = "Site Assets";
				}
				if (checkBox2.Checked)
				{
					documentLibraryName = "Risorse del sito";
				}
				if (documentLibraryName == "") {
					MessageBox.Show("Non hai selezionato la lingua del sito nel tab CONFIG");
				}

				textBox2.Text  += Environment.NewLine;
				textBox2.Text +=  DateTime.Now.ToString("dd/MM/yyyy HH:MM")+" Deploy Iniziato... attendere";
				// Make an object of your SharePoint site.
				//ClientContext site = new ClientContext(textBox1.Text);
				using (ClientContext site = new ClientContext(urlSite))
				{
					System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
					site.Credentials = new NetworkCredential(textBoxUser.Text, textBoxPassword.Text, textBoxDominio.Text);
					site.ExecutingWebRequest += Ctx_ExecutingWebRequest;
					site.ExecuteQuery();
					Web web = site.Web;
					site.Load(web);
					site.ExecuteQuery();
					List list = web.Lists.GetByTitle(documentLibraryName);
					site.Load(list);
					site.ExecuteQuery();
					site.Load(list.RootFolder);
					site.ExecuteQuery();
					site.Load(list.RootFolder.Folders);
					site.ExecuteQuery();
					string folderInSitesAssets = textBox5.Text;
					Folder rootFolder = web.GetFolderByServerRelativeUrl(list.RootFolder.ServerRelativeUrl + "/" + folderInSitesAssets);

					//site.Load(rootFolder);
					site.ExecuteQuery();

					CreateDirectories(localPath, list.RootFolder.Folders, list.RootFolder.ServerRelativeUrl + "/" + folderInSitesAssets, site, type);
					
					textBox2.Text +=" --  Deploy Terminato "+urlSite.Split('/').Last();
					soundPlayer.Play();


				}
				
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error:" + ex.Message);
			}
		}
		private void CreateDirectories(string path, FolderCollection oFolderCollection, string folderCollectionPath, ClientContext site, string type)
		{
			try {
			
				Web web = site.Web;
				site.Load(web);
				site.ExecuteQuery();

				if (type=="ultralight")
				{
					//Upload Multiple Files ULTRALIGHT
					foreach (FileInfo oFI in new DirectoryInfo(path).GetFiles())
					{
						if (oFI.LastWriteTimeUtc.Date >= DateTime.Today.Date)
						{
							//  FileStream fileStream = System.IO.File.OpenRead(oFI.FullName);
							using (FileStream fs = new FileStream(path + "\\" + oFI.Name, FileMode.Open))
							{
								Microsoft.SharePoint.Client.File.SaveBinaryDirect(site, folderCollectionPath + "/" + oFI.Name, fs, true);

							}
						}

					}
					//Upload Multiple Folders
					foreach (DirectoryInfo oDI in new DirectoryInfo(path).GetDirectories())
					{
						string sFolderName = oDI.FullName.Split('\\')

									[oDI.FullName.Split('\\').Length - 1];
						if (sFolderName != ".git")
						{
							if (type == "full")
							{
								Folder subfolder = web.GetFolderByServerRelativeUrl(folderCollectionPath);
								// web.GetFolderByServerRelativeUrl(folderCollectionPath).AddSubFolder(sFolderName);
								site.Load(subfolder);
								site.ExecuteQuery();
								subfolder.Folders.Add(sFolderName);
								site.ExecuteQuery();
								CreateDirectories(oDI.FullName, web.GetFolderByServerRelativeUrl(folderCollectionPath).Folders, folderCollectionPath + "/" + sFolderName, site, type);
							}
							else if (type == "light" )
							{
								if (sFolderName != "lib")
								{
									Folder subfolder = web.GetFolderByServerRelativeUrl(folderCollectionPath);
									// web.GetFolderByServerRelativeUrl(folderCollectionPath).AddSubFolder(sFolderName);
									site.Load(subfolder);
									site.ExecuteQuery();
									subfolder.Folders.Add(sFolderName);
									site.ExecuteQuery();
									CreateDirectories(oDI.FullName, web.GetFolderByServerRelativeUrl(folderCollectionPath).Folders, folderCollectionPath + "/" + sFolderName, site, type);
								}
							}
							else if (type == "ultralight") {
								if (sFolderName == "App" || sFolderName == "js" || sFolderName == "services" || sFolderName == "controllers" || sFolderName == "templates")
								{
									
									CreateDirectories(oDI.FullName, web.GetFolderByServerRelativeUrl(folderCollectionPath).Folders, folderCollectionPath + "/" + sFolderName, site, type);
								}
							}

						}

					}
				}
				else {
					//Upload Multiple Files
				foreach (FileInfo oFI in new DirectoryInfo(path).GetFiles())
				{

					//  FileStream fileStream = System.IO.File.OpenRead(oFI.FullName);
					using (FileStream fs = new FileStream(path + "\\" + oFI.Name, FileMode.Open))
					{
						Microsoft.SharePoint.Client.File.SaveBinaryDirect(site, folderCollectionPath + "/" + oFI.Name, fs, true);

					}
				}
					//Upload Multiple Folders
					foreach (DirectoryInfo oDI in new DirectoryInfo(path).GetDirectories())
					{
						string sFolderName = oDI.FullName.Split('\\')

									[oDI.FullName.Split('\\').Length - 1];
						if (sFolderName != ".git")
						{
							if (type == "full")
							{
								Folder subfolder = web.GetFolderByServerRelativeUrl(folderCollectionPath);
								// web.GetFolderByServerRelativeUrl(folderCollectionPath).AddSubFolder(sFolderName);
								site.Load(subfolder);
								site.ExecuteQuery();
								subfolder.Folders.Add(sFolderName);
								site.ExecuteQuery();
								CreateDirectories(oDI.FullName, web.GetFolderByServerRelativeUrl(folderCollectionPath).Folders, folderCollectionPath + "/" + sFolderName, site, type);
							}
							else if (type == "light")
							{
								if (sFolderName != "lib")
								{
									Folder subfolder = web.GetFolderByServerRelativeUrl(folderCollectionPath);
									// web.GetFolderByServerRelativeUrl(folderCollectionPath).AddSubFolder(sFolderName);
									site.Load(subfolder);
									site.ExecuteQuery();
									subfolder.Folders.Add(sFolderName);
									site.ExecuteQuery();
									CreateDirectories(oDI.FullName, web.GetFolderByServerRelativeUrl(folderCollectionPath).Folders, folderCollectionPath + "/" + sFolderName, site, type);
								}
							}

						}

					}
				}

				

			

			} catch (Exception ex) {
				textBox2.Text += ex.ToString();
			}
			
		}

		private void Button3_Click(object sender, EventArgs e)
		{
			textBox2.Text = "";
		}

		private void button1_Click_1(object sender, EventArgs e)
			
		{
			ChangeAppMainString(textBox1.Text);
			CopyFolderAndFiles("full", textBox1.Text);
			ReChangeAppMainString(textBox1.Text);

		}

		private void button4_Click(object sender, EventArgs e)
		{
			using (ClientContext ctx = new ClientContext(@"http://10.103.120.175")) //IP DELL’APPLICATIVO ESPOSTO IN NTLM | QUESTO LO FORNISCE IL MOET O IL TAD
			{
				//ctx.Credentials = new System.Net.NetworkCredential("co27931", "bitonto45", "eninet");
				//ctx.ExecutingWebRequest += Ctx_ExecutingWebRequest; //DA DEFINIRE PER FORZARE LA WINDOWS AUTH;
				//Web oweb = ctx.Web;
				////AppTiles property returns the collection App Tiles associated to the web    
				//AppTileCollection appTiles = oweb.AppTiles;
				//ctx.Load(appTiles);
				//ctx.ExecuteQuery();

			}
		}

		private void Ctx_ExecutingWebRequest(object sender, WebRequestEventArgs e)
		{
			try
			{
				//Add the header that tells SharePoint to use Windows authentication.
				e.WebRequestExecutor.RequestHeaders.Add(
				"X-FORMS_BASED_AUTH_ACCEPTED", "f");
			}
			catch (Exception ex)
			{

			}

		}

		private void button5_Click(object sender, EventArgs e)
		{
			ChangeAppMainString(textBox1.Text);
			CopyFolderAndFiles("light", textBox1.Text);
			ReChangeAppMainString(textBox1.Text);
		}

		private void button3_Click_1(object sender, EventArgs e)
		{
			textBox2.Text = "";
		}

		private void button6_Click(object sender, EventArgs e)
		{
			ChangeAppMainString(textBox1.Text);
			CopyFolderAndFiles("ultralight", textBox1.Text);
			ReChangeAppMainString(textBox1.Text);
		}

		private void button2_Click(object sender, EventArgs e)
		{
			XmlDataDocument xmldoc = new XmlDataDocument();
			XmlNodeList xmlnode;
			int i = 0;
			string str = null;
			FileStream fs = new FileStream("sites.xml", FileMode.Open, FileAccess.Read);
			xmldoc.Load(fs);
			xmlnode = xmldoc.GetElementsByTagName("BU");
			foreach (XmlNode bu in xmlnode) {
				ChangeAppMain(bu);
				CopyFolderAndFiles("full", bu.ChildNodes[0].InnerText);
				ReChangeAppMain(bu);
			}
		
		}

		private void ChangeAppMain(XmlNode bu)
		{
			string text = System.IO.File.ReadAllText(textBox3.Text +"\\App-main.txt");
			text = text.Replace("AppUrlConst", bu.ChildNodes[0].InnerText.Split('/').Last());
			System.IO.File.WriteAllText(textBox3.Text + "\\App-main.txt", text);
			string textApp = System.IO.File.ReadAllText(textBox3.Text + "\\js\\app.js");
			textApp = textApp.Replace("AppNameConst", bu.ChildNodes[1].InnerText);
			textApp = textApp.Replace("AppUrlConst", bu.ChildNodes[0].InnerText.Split('/').Last());
			textApp = textApp.Replace("DescriptionConst", bu.ChildNodes[2].InnerText);
			System.IO.File.WriteAllText(textBox3.Text + "\\js\\app.js", textApp);

		}
		private void ReChangeAppMain(XmlNode bu)
		{
			string text = System.IO.File.ReadAllText(textBox3.Text + "\\App-main.txt");
			text = text.Replace(bu.ChildNodes[0].InnerText.Split('/').Last(), "AppUrlConst");
			System.IO.File.WriteAllText(textBox3.Text + "\\App-main.txt", text);
			string textApp = System.IO.File.ReadAllText(textBox3.Text + "\\js\\app.js");
			textApp = textApp.Replace(bu.ChildNodes[1].InnerText,"AppNameConst");
			textApp = textApp.Replace(bu.ChildNodes[0].InnerText.Split('/').Last(), "AppUrlConst");
			textApp = textApp.Replace(bu.ChildNodes[2].InnerText,"DescriptionConst");
			System.IO.File.WriteAllText(textBox3.Text + "\\js\\app.js", textApp);

		}
		private void ChangeAppMainString(string bu)
		{
			string text = System.IO.File.ReadAllText(textBox3.Text + "\\App-main.txt");
			text = text.Replace("AppUrlConst", bu.Split('/').Last());
			System.IO.File.WriteAllText(textBox3.Text + "\\App-main.txt", text);
			string textApp = System.IO.File.ReadAllText(textBox3.Text + "\\js\\app.js");
			textApp = textApp.Replace("AppNameConst", bu.Split('/').Last());
			textApp = textApp.Replace("AppUrlConst", bu.Split('/').Last());
			textApp = textApp.Replace("DescriptionConst", bu.Split('/').Last());
			System.IO.File.WriteAllText(textBox3.Text + "\\js\\app.js", textApp);

		}
		private void ReChangeAppMainString(string bu)
		{
			string text = System.IO.File.ReadAllText(textBox3.Text + "\\App-main.txt");
			text = text.Replace(bu.Split('/').Last(), "AppUrlConst");
			System.IO.File.WriteAllText(textBox3.Text + "\\App-main.txt", text);
			string textApp = System.IO.File.ReadAllText(textBox3.Text + "\\js\\app.js");
			textApp = textApp.Replace(bu.Split('/').Last(), "AppNameConst");
			textApp = textApp.Replace(bu.Split('/').Last(), "AppUrlConst");
			textApp = textApp.Replace(bu.Split('/').Last(), "DescriptionConst");
			System.IO.File.WriteAllText(textBox3.Text + "\\js\\app.js", textApp);

		}
	}
}

